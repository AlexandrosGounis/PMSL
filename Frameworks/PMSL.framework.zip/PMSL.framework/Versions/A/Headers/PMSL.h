//  Created by Alexandros Gounis.
//  Copyright © 2018 Alexandros Gounis. All rights reserved.


#import <Cocoa/Cocoa.h>

//! Project version number for PMSL.
FOUNDATION_EXPORT double PMSLVersionNumber;

//! Project version string for PMSL.
FOUNDATION_EXPORT const unsigned char PMSLVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PMSL/PublicHeader.h>


